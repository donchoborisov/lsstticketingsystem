
<div class="comments">
     <?php if($ticket->comments->isEmpty()): ?>
     <p class="text-center">no comments for this ticket</p>
     <?php else: ?>

     <?php $__currentLoopData = $ticket->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="panel panel-<?php if($ticket->user->id === $comment->user_id): ?><?php echo e("default"); ?> <?php else: ?> <?php echo e("success"); ?> <?php endif; ?> ">
            <div class="panel panel-heading">
                <b><?php echo e($comment->user->name); ?></b>
 
                <span class="pull-right"><?php echo e($comment->created_at->diffForHumans()); ?></span>
            </div>
 
            <div class="message2">
                <?php echo e($comment->comment); ?>

            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
  
     

    <?php endif; ?>
</div><?php /**PATH C:\xampp\htdocs\Ticketing\resources\views/tickets/comments.blade.php ENDPATH**/ ?>