
<?php $__env->startSection('title',$ticket->title); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
               <div class="card-header">
              <b> #<?php echo e($ticket->ticket_id); ?>-<?php echo e($ticket->title); ?></b>
               </div>
               <div class="card-body">
               <?php if(session('status')): ?> 
               <span class="badge badge-primary">
               <?php echo e(session('status')); ?>

             </span>
               <?php endif; ?>
             <div class="card-text">
             <b>Ticket message:</b> <div class="message"><?php echo e($ticket->message); ?></div><hr>
             <p><b>Category:</b>  <?php echo e($ticket->category->name); ?></p>
             <p><b>Priority: </b>
             <?php if($ticket->priority == "low"): ?>
            <span class="badge badge-pill badge-outline-success"><?php echo e($ticket->priority); ?></span>
             <?php elseif($ticket->priority == "medium"): ?>
             <span class="badge badge-pill badge-outline-warning"><?php echo e($ticket->priority); ?></span>

             <?php else: ?>
             <span class="badge badge-pill badge-outline-danger"><?php echo e($ticket->priority); ?></span>
             <?php endif; ?>

              

             </p>

             <?php if($ticket->image == NULL): ?>

             <?php else: ?>
             <img src="<?php echo e(asset($ticket->image)); ?>" class="ticket">  
             <?php endif; ?>

             <p>
                <?php if($ticket->status == 'Open'): ?>
                  <b>Status:</b>  <span class="badge badge-success"><?php echo e($ticket->status); ?></span>
                <?php else: ?>
                <b>Status:</b> <span class="badge badge-danger"><?php echo e($ticket->status); ?></span>
                <?php endif; ?>  
             </p>
             <p><b>Created by:</b> <?php echo e($ticket->user->name); ?></p>
             <p><b>Campus:</b> <?php echo e($ticket->campus->name); ?></p>
             <p><b>Created:</b> <?php echo e($ticket->created_at->diffForHumans()); ?></p>
            </div>
             






               </div>
              
                
                
            </div>
            <hr>
            <?php echo $__env->make('tickets.comments', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <hr>
            <?php echo $__env->make('tickets.reply', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ticketing\resources\views/tickets/show.blade.php ENDPATH**/ ?>