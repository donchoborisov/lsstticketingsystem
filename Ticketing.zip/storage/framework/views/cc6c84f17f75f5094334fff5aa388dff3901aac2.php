
 
<?php $__env->startSection('title', 'Open Ticket'); ?>
 
<?php $__env->startSection('content'); ?>
 <div class="container">
    <div class="row justify-content-center" >
        <div class="col-md-8 ">
            <div class="card">
                <div class="card-header"><b>Open New Ticket</b></div>
 
                <div class="card-body">
 
 
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
 
                    <form class="form-horizontal" role="form" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

 
                        <div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
                            <label for="title" class="col-md-4 control-label"><b>Title</b></label>
 
                            <div class="col-md-8">
                                <input id="title" placeholder="Title" type="text" class="form-control" name="title" value="<?php echo e(old('title')); ?>">
 
                                <?php if($errors->has('title')): ?>
                                <span class="error" style="color:#FF0000;">
                                        <strong><?php echo e($errors->first('title')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            
                        </div>
                            
                        <div class="form-group<?php echo e($errors->has('category') ? ' has-error' : ''); ?>">
                            <label for="category" class="col-md-4 control-label"><b>Category</b></label>
 
                            <div class="col-md-8">
                                <select id="category" type="category" class="form-control" name="category">
                                    <option value="">Select Category</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
 
                                <?php if($errors->has('category')): ?>
                                      <span class="help-block" style="color:#FF0000;">
                                        <strong><?php echo e($errors->first('category')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
 
                        <div class="form-group<?php echo e($errors->has('priority') ? ' has-error' : ''); ?>">
                            <label for="priority" class="col-md-4 control-label"><b>Priority</b></label>
 
                            <div class="col-md-8">
                                <select id="priority" type="" class="form-control" name="priority">
                                    <option value="">Select Priority</option>
                                    <option value="low">Low</option>
                                    <option value="medium">Medium</option>
                                    <option value="high">High</option>
                                </select>
 
                                <?php if($errors->has('priority')): ?>
                                <span class="help-block" style="color:#FF0000;">
                                        <strong><?php echo e($errors->first('priority')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group <?php echo e($errors->has('campus') ? ' has-error' : ''); ?>">
                            <label for="campus" class="col-md-4 control-label"><b>Campus</b></label>
                            <?php
                            $campuses = DB::table('campuses')->get();
                             ?>

 
                            <div class="col-md-8">
                                <select id="campus" type="" class="form-control" name="campus">
                                    <option value="">Select Campus</option>
                                    <?php $__currentLoopData = $campuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($campus->id); ?>"><?php echo e($campus->name); ?></option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
 
                                <?php if($errors->has('campus')): ?>
                                <span class="help-block" style="color:#FF0000;">
                                        <strong><?php echo e($errors->first('campus')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="title" class="col-md-4 control-label"><b>Image</b></label>
 
                            <div class="col-md-8">
                                <input id="title" placeholder="Title" type="file" class="form-control" name="image" onchange="readURL(this);">
                                <span class="custom-file-control"></span>
                                <img src="" id="one">
                            
                        </div>
 
                        <div class="form-group<?php echo e($errors->has('message') ? ' has-error' : ''); ?>">
                            <label for="message" class="col-md-4 control-label"><b>Message</b></label>
 
                            <div class="col-md-8">
                                <textarea rows="10" id="message" class="form-control" placeholder="Message.." name="message"></textarea>
 
                                <?php if($errors->has('message')): ?>
                                <span class="help-block" style="color:#FF0000;">
                                        <strong><?php echo e($errors->first('message')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
 
                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                                <button type="submit" class="btn btn-danger">
                                    <i class="fa fa-btn fa-ticket"></i> Open Ticket
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
 
    </div>

 <script type="text/javascript">
  function readURL(input){
    if (input.files && input.files[0]) {
      var reader = new FileReader();
      reader.onload = function(e) {
        $('#one')
        .attr('src', e.target.result)
        .width(80)
        .height(80);
      };
      reader.readAsDataURL(input.files[0]);
    }
  }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ticketing\resources\views/tickets/create.blade.php ENDPATH**/ ?>