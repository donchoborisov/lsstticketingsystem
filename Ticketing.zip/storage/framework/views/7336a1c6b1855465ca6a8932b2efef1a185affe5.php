
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Support Ticket</title>
</head>
<body>
<p>
    <?php echo e($comment->comment); ?>

</p>
 
---
<p>Replied by: <?php echo e($user->name); ?></p>
 
<p>Title: <?php echo e($ticket->title); ?></p>
<p>Ticket ID: <?php echo e($ticket->ticket_id); ?></p>
<p>Status: <?php echo e($ticket->status); ?></p>
 
<p>
    You can view the ticket at any time at <?php echo e(url('tickets/'. $ticket->ticket_id)); ?>

</p>
 
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Ticketing\resources\views/emails/ticket_comments.blade.php ENDPATH**/ ?>