
<?php $__env->startSection('title','All Tickets'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
<div class="row justify-content-center">
<div class="col-md-10">
<div class="card ">

<div class="card-header">
<h3>Your Tickets</h3>
<?php if($tickets->isEmpty()): ?>
<p>You have not created any tickets.</p>
</div>
<?php else: ?>
<div class="card-body">
<table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">Category</th>
      <th scope="col">Title</th>
      <th scope="col">Priority</th>
      <th scope="col">Status</th>
      <th scope="col">Last Updated</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td>
        <?php echo e($ticket->category->name); ?>

      </td>
      <td>
      <a href="<?php echo e(url('tickets/'.$ticket->ticket_id)); ?>">
         #<?php echo e($ticket->ticket_id); ?> - <?php echo e($ticket->title); ?> 
      </td>
      <td>
       <?php if($ticket->priority == "low"): ?>
       <span class="badge badge-pill badge-outline-success"><?php echo e($ticket->priority); ?></span>
       <?php elseif($ticket->priority == "medium"): ?>
       <span class="badge badge-pill badge-outline-warning"><?php echo e($ticket->priority); ?></span>

       <?php else: ?>
       <span class="badge badge-pill badge-outline-danger"><?php echo e($ticket->priority); ?></span>
       <?php endif; ?>
      
      
      </td>
      <td>
          <?php if($ticket->status == 'Open'): ?>
          <span class="badge badge-success"><?php echo e($ticket->status); ?></span>
          <?php else: ?>
          <span class="badge badge-danger"><?php echo e($ticket->status); ?></span>
          <?php endif; ?>
      </td>
      <td>
      <?php echo e($ticket->updated_at->diffForHumans()); ?>

      </td>
     
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
  </tbody>
</table>
<div

 <?php echo e($tickets->render()); ?>

<?php endif; ?>
</div>
</div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ticketing\resources\views/tickets/user_tickets.blade.php ENDPATH**/ ?>