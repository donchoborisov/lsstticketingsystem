<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-theme.min.css">
<script src="https://code.jquery.com/jquery-1.11.2.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script>
$(document).ready(function(){
    $('a[data-toggle="tab"]').on('show.bs.tab', function(e) {
        localStorage.setItem('activeTab', $(e.target).attr('href'));
    });
    var activeTab = localStorage.getItem('activeTab');
    if(activeTab){
        $('#myTab a[href="' + activeTab + '"]').tab('show');
    }
});
</script>
<div class="container">


    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <?php if(Auth::user()->is_admin): ?>
                <div class="card-header"><b>Admin Panel</b></div>
                <?php else: ?>
                <div class="card-header"><b>Dashboard</b></div>
                <?php endif; ?>

                <div class="card-body">
                <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session('delete')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('delete')); ?>

                        </div>
                    <?php endif; ?>



                <?php if(Auth::user()->is_admin): ?>
                 
                <div class="row">
  <div class="col-4">
    <div class="list-group" id="myTab" role="tablist">
      <a class="list-group-item list-group-item-action active" id="list-home-list"  href="<?php echo e(url('admin/tickets')); ?>" data-toggle="tooltip" data-placement="right"  title="Click to view all tickets" role="tab" aria-controls="home"><i class="fa fa-ticket" aria-hidden="true"></i> View All Tickets</a>
      <a class="list-group-item list-group-item-action" id="list-profile-list" data-toggle="tab" href="#list-profile"  role="tab" aria-controls="profile"><i class="fa fa-building-o" aria-hidden="true"></i> Tickets by Campus</a>
      <a class="list-group-item list-group-item-action" id="list-messages-list" data-toggle="tab" href="#list-messages"   role="tab" aria-controls="messages"><i class="fa fa-plus-square" aria-hidden="true"></i> Add Campus</a>
      <a class="list-group-item list-group-item-action" id="list-settings-list" data-toggle="tab" href="#list-settings"   role="tab" aria-controls="settings"><i class="fa fa-plus-square" aria-hidden="true"></i> Add Category</a>
    </div>
  </div>
  <div class="col-8">
    <div class="tab-content" id="nav-tabContent">
      <div class="tab-pane fade" id="list-profile" role="tabpanel" aria-labelledby="list-profile-list">
      <form class="form-inline mt-2" method="GET" action="<?php echo e(url('/admin/campus/tickets')); ?>"><?php echo csrf_field(); ?>
<?php
 $campuses = DB::table('campuses')->get();
?>


<div class="form-group mx-sm-3 mb-2 <?php echo e($errors->has('Campus') ? ' has-error' : ''); ?>">
  <label for="campus" class="sr-only">Campus</label>
 
    <select class="custom-select mr-sm-2" name="Campus">
       <option value="">Choose Campus</option>
         <?php $__currentLoopData = $campuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($campus->id); ?>"><?php echo e($campus->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </select>
  
</div>


<button type="submit" class="btn btn-outline-secondary  btn-sm mb-2">View Tickets</button>
</form>
<div class="error">
     <?php if($errors->has('Campus')): ?>
    <span class="error" style="color:#FF0000;">
    <small><strong><?php echo e($errors->first('Campus')); ?></strong></small>
    </span>
    <?php endif; ?>
</div>


      </div>
      <div class="tab-pane fade" id="list-messages" role="tabpanel" aria-labelledby="list-messages-list">
      <form class="form-inline mt-2" method="post" action="<?php echo e(url('/admin/new-campus')); ?>"><?php echo csrf_field(); ?>

<div class="form-group mx-sm-3 mb-2 <?php echo e($errors->has('campus') ? ' has-error' : ''); ?>">
  <label for="campus" class="sr-only">Campus</label>
 
  <input type="text" name="campus" class="form-control shadow-none" id="campus" placeholder="Campus Name" >
                            

                         
                      
</div>
<button type="submit" class="btn btn-outline-secondary  btn-sm mb-2">Add Campus</button> 
                               
                            

</form>
<div class="error">
     <?php if($errors->has('campus')): ?>
    <span class="error" style="color:#FF0000;">
    <small><strong><?php echo e($errors->first('campus')); ?></strong></small>
    </span>
    <?php endif; ?>
</div>
<br>

<table class="table table-sm">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Campus</th>
      <th scope="col"></th>
   
    </tr>
  </thead>
  <tbody>
      <?php $__currentLoopData = $campuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
  
      <td><?php echo e($key +1); ?></td>
      <td><?php echo e($row->name); ?></td>
      <td><a href="<?php echo e(url('/admin/delete/campus/'. $row->id)); ?>" class="btn btn-sm btn-danger"><i class="fa fa-trash-o" aria-hidden="true"></i></a></td>
    </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
  </tbody>
</table>



      </div>

      <?php
 $category = DB::table('categories')->get();
?>

      <div class="tab-pane fade" id="list-settings" role="tabpanel" aria-labelledby="list-settings-list">
      <form class="form-inline mt-2" method="post" action="<?php echo e(url('/admin/new-category')); ?>"><?php echo csrf_field(); ?>

<div class="form-group mx-sm-3 mb-2 <?php echo e($errors->has('category') ? ' has-error' : ''); ?>">
  <label for="category" class="sr-only">Category</label>
  <input type="text" name="category" class="form-control" id="category" placeholder="Category Name">

                            
</div>
<button type="submit" class="btn btn-outline-secondary  btn-sm mb-2">Add Category</button>
</form>
<div class="error">
<?php if($errors->has('category')): ?>
<span class="error" style="color:#FF0000;">
<small><strong><?php echo e($errors->first('category')); ?></strong></small>
</span>
 <?php endif; ?>

 <br>

<table class="table table-sm">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Category</th>
      <th scope="col"></th>
   
    </tr>
  </thead>
  <tbody>
      <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
  
      <td><?php echo e($key +1); ?></td>
      <td><?php echo e($row->name); ?></td>
      <td><a href="<?php echo e(url('/admin/delete/category/'. $row->id)); ?>" class="btn btn-sm btn-danger"><i class="fa fa-trash-o" aria-hidden="true"></i></a></td>
    </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
  </tbody>
</table>


</div>


      </div>
    </div>
  </div>
</div>

 









                <?php else: ?>
                <p>You are logged in to the LSST Ticketing System</p>

                <div class="d-flex justify-content-around mb-3">
                <a class="btn btn-secondary" href="<?php echo e(url('my_tickets')); ?>" role="button">View your Tickets</a> 
                <a class="btn btn-danger btn-outline" href="<?php echo e(url('new-ticket')); ?>" role="button">Create New Ticket</a>
               </div>

             
                 
                <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Ticketing\resources\views/home.blade.php ENDPATH**/ ?>